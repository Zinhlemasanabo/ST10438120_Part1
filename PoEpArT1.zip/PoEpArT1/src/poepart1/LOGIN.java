/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poepart1;
import java.util.Scanner;
/**
 *
 * @author zizinhle masanabo
 */
public class LOGIN {
    
    
    String passMessage;
    
    String nameMessage;
   
    /*Check to see if the username contains an underscore and is not longer than 5 letters*/
    public boolean checkUserName(String userName){
        return userName.contains("_") && userName.length() <= 5;
    }

    /*Check if the password is at least 8 characters long, contains an upercase, a number and a special character*/
    public boolean checkPasswordComplexity(String password){
        
        boolean passwordOkay = false;
        boolean hasNumber = false;
        boolean hasCap = false;
        boolean hasChar = false;
        char current;
        
        // loop executes only if the password meets the length constraint
        if (password.length() >= 8){ 
            for (int i =0; i < password.length(); i++){
                current = password.charAt(i);

                if(Character.isDigit(current)){
                    hasNumber = true;
                }
                else if(Character.isUpperCase(current)){
                    hasCap = true;
                }
                else if (!(Character.isLetterOrDigit(current))){
                    hasChar = true;
                }
            }
        }    
            
        if(hasNumber && hasCap && hasChar){
            passwordOkay = true;
        }
        return passwordOkay;
        
    }

    /*The method takes a password and a username as arguments.
    * It then returns a message that is determined by whether the password and username meet the entry requirements.
    */
    public String registerUser(String pass, String name){
        if (checkPasswordComplexity(pass)){
            passMessage = "Password successfully captured.";
        }
        else{
            passMessage = "Password is not correctly formatted, please ensure that the password contains at least 8 characters, "
            + "a capital letter, a number and a special character";
        }
        
        if (checkUserName(name)){
            nameMessage = "User name successfully captured.";
        }
        else{
            nameMessage = "Username is not correctly formatted, please ensure that your "
                    + "username contains an underscore and is no more than 5 characters in length";
        }
        
        return (nameMessage+ "\n" + passMessage);
    }

    
    public boolean loginUser(boolean checkName, boolean checkPassword, String passwrd, String userName){
        
        boolean logged = false;
        if(checkName && checkPassword) { //only run if the user successfully registered

            Scanner in = new Scanner(System.in);
            System.out.println("");
            System.out.println(" *** LOGIN *** ");            
            System.out.print("Enter the username you used to register: ");
            String username = in.nextLine();
            System.out.print("Enter the password you used to register: ");
            String password = in.nextLine();
            
            if (password.equals(passwrd) && username.equals(userName)  ){
                logged = true;
            }
        }
        return logged;
    }
    
    
    public String returnLoginStatus(boolean regStatus, String name, String surname){
        String message;
        
        /*
        To avoid unnecessary messages, the login status will only be returned if the user managed to register an account.
        Meaning that an appropriate message will only be displayed depending on wether the login details meet the details
        used to create an account*/
        
        message = "Username and/or password incorrect, please try again";
        
        if (regStatus){
            message = "Welcome, " + name + " " + surname + ", it is great to see you again.";
        }
        return message;
    }

    //test data 
    String user_name = "kyl_1";
    String password = "Ch&&sec@ke99!";

    
}
