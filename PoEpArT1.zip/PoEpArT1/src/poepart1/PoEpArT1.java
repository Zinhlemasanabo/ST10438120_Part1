
package poepart1;
import java.util.Scanner;
public class PoEpArT1 {

    
    private static String username;
    private static String password;
    private static String name;
    private static String surName;
    
   {
    // Display a welcome message 
    System.out.println("Welcome to the Registration and Login System");
    // Loop until the user succesfully logs in or exits
    }
    //set to find the username
    public static void setUserName(String name){               
        username = name;
    }
    public static String getUserName(){
        return username;
    }
    //set to find the password
    public static void setPassword(String pass){
        password = pass;
    }
    public static String getPassword(){
        return password;
    }
    //set and get the user's name
    public static void setName(String naame){
        name = naame;
    }
    public static String getName(){
        return name;
    }
    
    //set and get the user's surname
    public static void setSurname(String surname){
        surName = surname;
    }
    public static String getSurname(){
        return surName;
    }
    

    public static void main(String[] args)
    {
    
        LOGIN loginObj = new LOGIN();
                       
     /*Prompt the user for the required input and then pass the input directly to the methods that use it*/   
        Scanner data = new Scanner(System.in);
        boolean logged=false;
        while(!logged){
            
        System.out.println(" ");
        System.out.println(" *** REGISTRATION *** ");
        
        System.out.println("Enter your first name as it appears on your ID: ");
        setName(data.nextLine());
        
        System.out.println("Enter your surname as it appears on your ID: ");
        setSurname(data.nextLine());
        
        
        System.out.println("Enter your username: ");
        setUserName(data.nextLine());
        
        loginObj.checkUserName(getUserName()); // ensure the username meets the requirements
        
        System.out.println("Enter your password: ");
        setPassword(data.nextLine());                

        loginObj.checkPasswordComplexity(password); // ensure the password meets the requirements
        
        
        /*Progress the username and password to the method and then print out the messages returned by the method*/
        System.out.println( loginObj.registerUser( getPassword(), getUserName() ));
        
        //Save the boolean value returned by loginUser() in the regStatus varible. The boolean value will used in the returnLoginStatus method
        boolean regStatus = loginObj.loginUser(loginObj.checkUserName(getUserName()) ,loginObj.checkPasswordComplexity(getPassword()), getPassword(), getUserName());
        
        System.out.println(loginObj.returnLoginStatus(regStatus, getName(), getSurname()));
        logged=regStatus;
    
    }
    }
}
