/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package poepart1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class PoEpArT1Test {
    
    public PoEpArT1Test() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of setUserName method, of class PoEpArT1.
     */
    @Test
    public void testSetUserName() {
        System.out.println("setUserName");
        String name = "";
        PoEpArT1.setUserName(name);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getUserName method, of class PoEpArT1.
     */
    @Test
    public void testGetUserName() {
        System.out.println("getUserName");
        String expResult = "";
        String result = PoEpArT1.getUserName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setPassword method, of class PoEpArT1.
     */
    @Test
    public void testSetPassword() {
        System.out.println("setPassword");
        String pass = "";
        PoEpArT1.setPassword(pass);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPassword method, of class PoEpArT1.
     */
    @Test
    public void testGetPassword() {
        System.out.println("getPassword");
        String expResult = "";
        String result = PoEpArT1.getPassword();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setName method, of class PoEpArT1.
     */
    @Test
    public void testSetName() {
        System.out.println("setName");
        String naame = "";
        PoEpArT1.setName(naame);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getName method, of class PoEpArT1.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        String expResult = "";
        String result = PoEpArT1.getName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSurname method, of class PoEpArT1.
     */
    @Test
    public void testSetSurname() {
        System.out.println("setSurname");
        String surname = "";
        PoEpArT1.setSurname(surname);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSurname method, of class PoEpArT1.
     */
    @Test
    public void testGetSurname() {
        System.out.println("getSurname");
        String expResult = "";
        String result = PoEpArT1.getSurname();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class PoEpArT1.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        PoEpArT1.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
